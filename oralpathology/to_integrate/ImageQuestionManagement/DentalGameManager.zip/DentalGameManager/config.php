<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

define('MYSQL_HOST', 'localhost:8889');
define('MYSQL_USER', 'root');
define('MYSQL_PW', 'root');
define('MYSQL_DB', 'DentalGameTest');

define('MYSQL_HOST_DENTAL', 'sis-teach-01.sis.pitt.edu');
define('MYSQL_USER_DENTAL', 'dentalgame');
define('MYSQL_PW_DENTAL', 'D3n!alGam@');
define('MYSQL_DB_DENTAL', 'dentalgame');

